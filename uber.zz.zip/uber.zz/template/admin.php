<?php
    if (!getUser()) {
        header('location: /login');
    }
?>
<h1>admin</h1>
