<?php
if (!getUser()) {
    header('location: /');
}
if (isset($_POST['unlog'])) {
    clearCookies();
    header('location: /');
    exit();
}
?>
<h1>admin</h1>
<form method="POST">
    <input type="submit" name="unlog" value="выйти">
</form>

<?php
$out = '';
for ($i = 0; $i < count($result); $i++) {
    $out .= '<div>';
    $out .= '<h4>' . $result[$i]['name'] . '</h4>';
    $out .= '<p>' . $result[$i]['email'] . '</p>';
    $out .= '<p>' . $result[$i]['message'] . '</p>';
    $out .= '<p>тут будет кнопка или форма удаления</p>';
    $out .= '<p>тут будет кнопка или форма редактирования</p>';
    $out .= '</div>';
}
echo $out;
?>
