<?php
if (isset($_POST['submit'])) {
    $user = login($_POST['login'],$_POST['password']);
    if ($user) {
        $user = $user[0];
        $hash = md5(generateCode(10));
        updateUser($user['id'], $hash);
        setcookie('id',$user['id'], time()+60*60*24*30, "/");
        setcookie('hash',$hash, time()+60*60*24*30, "/");
        header('location: /admin');
        exit();
    }
}
?>
    <h2>логин</h2>
    <form method="POST">
        login: <input type="text" name="login" required><br>
        Pass: <input type="password" name="password" required>
        <input type="submit" name="submit" value="войти">
    </form>

<?php
$out = '';
for ($i = 0; $i < count($result); $i++) {
    $out .='<div>';
    $out .= '<h4>' . $result[$i]['name'] . '</h4>';
    $out .= '<p>' . $result[$i]['email'] . '</p>';
    $out .= '<p>' . $result[$i]['message'] . '</p>';
    $out .='<p>тут будет кнопка или форма удаления</p>';
    $out .='</div>';
}
echo $out;
?>
<form method="POST">
    Имя: <input type="text" name="name" required><br>
    Email: <input type="password" name="email" required><br>
    Сообщение: <input type="password" name="message" required><br>
    <input type="submit" name="publication" value="отправить">
</form>
