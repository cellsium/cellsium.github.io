<?php
$out = '';
for ($i = 0; $i < count($result); $i++) {
    $out .='<div>';
    $out .='<h4>'.$result[$i]['title'].'</h4>';
    $out .='<p>'.$result[$i]['descr_min'].'</p>';
    $out .='<img src="'.$result[$i]['image'].'" width=200>';
    $out .='<p>тут будет кнопка или форма удаления</p>';
    $out .='</div>';
}
echo $out;
?>