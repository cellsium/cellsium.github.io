-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Мар 02 2021 г., 17:12
-- Версия сервера: 10.3.22-MariaDB
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `beejee`
--
CREATE DATABASE IF NOT EXISTS `beejee` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `beejee`;

-- --------------------------------------------------------

--
-- Структура таблицы `info`
--

CREATE TABLE `info` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` varchar(1024) NOT NULL,
  `checkin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `info`
--

INSERT INTO `info` (`id`, `name`, `email`, `message`, `checkin`) VALUES
(24, 'adfasd', 'asda@masa.ru', 'edesahegretvawe', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `login` varchar(30) NOT NULL,
  `password` varchar(32) NOT NULL,
  `hash` varchar(32) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `hash`) VALUES
(1, 'admin', 'd9b1d7db4cd6e70935368a1efb10e377', '88ab07b1cdf8233c1d346ebd4ca25baa');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `info`
--
ALTER TABLE `info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- База данных: `nemo`
--
CREATE DATABASE IF NOT EXISTS `nemo` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `nemo`;

-- --------------------------------------------------------

--
-- Структура таблицы `cable`
--

CREATE TABLE `cable` (
  `id` int(11) NOT NULL,
  `sklad` varchar(255) NOT NULL COMMENT 'наличие на складе',
  `m` varchar(255) NOT NULL COMMENT 'длинна',
  `stamp` varchar(255) NOT NULL COMMENT 'марка кабеля',
  `pu` varchar(255) NOT NULL COMMENT 'площадка',
  `coil` varchar(255) NOT NULL COMMENT '№ барабана',
  `ship` varchar(255) NOT NULL COMMENT '№ заказа'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `cable`
--

INSERT INTO `cable` (`id`, `sklad`, `m`, `stamp`, `pu`, `coil`, `ship`) VALUES
(1, 'Новая площадка', '1600', 'КМПВэ-НГ-БГ', '2', '39', 'МРК');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(255) NOT NULL COMMENT 'Имя пользователя (логин)',
  `email` varchar(255) NOT NULL COMMENT 'Почта пользователя',
  `hash` varchar(255) NOT NULL,
  `role` int(11) NOT NULL COMMENT 'Роль(статус) пользователя'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cable`
--
ALTER TABLE `cable`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cable`
--
ALTER TABLE `cable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- База данных: `stage2_project`
--
CREATE DATABASE IF NOT EXISTS `stage2_project` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `stage2_project`;

-- --------------------------------------------------------

--
-- Структура таблицы `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `url` varchar(255) NOT NULL,
  `title` varchar(500) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `category`
--

INSERT INTO `category` (`id`, `url`, `title`, `description`) VALUES
(1, 'garry-potter', 'Гарри Поттер', 'Все шутки о сабже'),
(2, 'angry', 'Бесят', 'Шутки о том, что все бесят');

-- --------------------------------------------------------

--
-- Структура таблицы `info`
--

CREATE TABLE `info` (
  `id` int(11) NOT NULL,
  `cid` int(4) NOT NULL,
  `title` varchar(255) NOT NULL,
  `descr_min` varchar(1024) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `login` varchar(30) NOT NULL,
  `password` varchar(32) NOT NULL,
  `hash` varchar(32) NOT NULL DEFAULT '',
  `ip` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `info`
--
ALTER TABLE `info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- База данных: `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `test`;

-- --------------------------------------------------------

--
-- Структура таблицы `group`
--

CREATE TABLE `group` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `header` varchar(255) CHARACTER SET utf8 NOT NULL,
  `main` varchar(255) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `group`
--
ALTER TABLE `group`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `group`
--
ALTER TABLE `group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- База данных: `zakazuha`
--
CREATE DATABASE IF NOT EXISTS `zakazuha` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `zakazuha`;

-- --------------------------------------------------------

--
-- Структура таблицы `product`
--

CREATE TABLE `product` (
  `id` int(255) NOT NULL COMMENT 'id товара',
  `name` varchar(255) NOT NULL COMMENT 'название товара',
  `idUserWork` int(255) NOT NULL COMMENT 'id заказчика на этот товар',
  `idUserCompleate` int(255) NOT NULL COMMENT 'id исполнителя заказа',
  `workLocation` int(255) DEFAULT NULL COMMENT 'geo локация товара',
  `count` int(255) NOT NULL COMMENT 'колличество товара',
  `cost` int(255) NOT NULL COMMENT 'стоимость товара',
  `image` varchar(255) DEFAULT NULL COMMENT 'ссылка на изображение продукта'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `product`
--

INSERT INTO `product` (`id`, `name`, `idUserWork`, `idUserCompleate`, `workLocation`, `count`, `cost`, `image`) VALUES
(1, 'RedLabel', 1, 1, 123, 1, 4500, 'https://drinkbay.ru/upload/iblock/ea0/ea017b83174e9bd1bf2eda637eafa83a.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(111) NOT NULL COMMENT 'id пользователя',
  `status` int(11) DEFAULT NULL COMMENT 'статус пользователя для привилегий',
  `login` varchar(255) NOT NULL COMMENT 'логин пользователя',
  `password` varchar(255) NOT NULL COMMENT 'пароль пользователя',
  `email` varchar(255) DEFAULT NULL COMMENT 'email пользователя',
  `phone` varchar(255) DEFAULT NULL COMMENT 'номер телефона пользователя',
  `federation` varchar(255) DEFAULT NULL COMMENT 'страна пользователя',
  `geolocation` varchar(255) DEFAULT NULL COMMENT 'geo локация пользователя',
  `backgroundUser` varchar(500) DEFAULT NULL COMMENT 'задний фон пользователя',
  `active` int(10) DEFAULT NULL COMMENT 'свободен/занят (0 или 1)',
  `feedback` varchar(500) DEFAULT NULL COMMENT 'отзыв о пользователе',
  `ip` varchar(50) DEFAULT NULL COMMENT 'ip пользователя',
  `hash` varchar(255) DEFAULT NULL,
  `alert` int(10) DEFAULT NULL COMMENT 'включение/отключение оповещений (0 или 1)',
  `raiting` int(10) DEFAULT NULL COMMENT 'рейтинг пользователя\r\n(от 1 до 5)',
  `work` int(10) DEFAULT NULL COMMENT 'исполнитель или заказчик (0 или 1)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `status`, `login`, `password`, `email`, `phone`, `federation`, `geolocation`, `backgroundUser`, `active`, `feedback`, `ip`, `hash`, `alert`, `raiting`, `work`) VALUES
(6, NULL, 'admin', '14e1b600b1fd579f47433b88e8d85291', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2130706433', 'bb43c0e0ec528b04677fa10df1b3aa79', NULL, NULL, NULL);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `product`
--
ALTER TABLE `product`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT COMMENT 'id товара', AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(111) NOT NULL AUTO_INCREMENT COMMENT 'id пользователя', AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
